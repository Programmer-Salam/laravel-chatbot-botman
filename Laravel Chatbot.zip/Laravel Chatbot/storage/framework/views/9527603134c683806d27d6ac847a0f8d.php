
  
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center align-items-center " style="height: 70vh;S">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading font-weight-bold">Register</div>
                <hr>
                <?php if($errors->any()): ?>
                    <div class="col-md-12">
                        <div class="alert alert-danger">
                          <strong><?php echo e($errors->first()); ?></strong>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('2fa')); ?>">
                        <?php echo e(csrf_field()); ?>

  
                        <div class="form-group">
                            <p>Please enter the  <strong>OTP</strong> generated on your Authenticator App. <br> Ensure you submit the current one because it refreshes every 30 seconds.</p>
                            <label for="one_time_password" class="col-md-4 control-label">One Time Password</label>
  
                            <div class="col-md-6">
                                <input id="one_time_password" type="number" class="form-control" name="one_time_password" required autofocus>
                            </div>
                        </div>
  
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4 mt-3">
                                <button type="submit" class="btn btn-primary">
                                    Login
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\first-laravel9\resources\views/google2fa/index.blade.php ENDPATH**/ ?>