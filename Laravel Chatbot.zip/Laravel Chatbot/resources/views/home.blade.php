@extends('layouts.app')

@section('content')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" ></script> 
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css"/>
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
    <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script> 
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('You are logged in!') }}

                    <table class="table table-bordered">
<?php 
$id=Auth::user();

  ?>
  <h1 style="text-align:center;">Push Notification</h1>

            <thead>
               <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Status</th>
                  <th>Enable/Disable Notification</th>

               </tr> 
            </thead>
            <tbody>
            <tr>
              <td><?php echo Auth::user()->name; ?></td>
              <td><?php echo Auth::user()->email; ?></td>
              <td><?php echo Auth::user()->status; ?></td>
              <td> 
                <input data-id="{{Auth::user()->id}}" class="toggle-class" type="checkbox" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Active" data-off="InActive" {{  $id->status ? 'checked' : '' }}>
</td>

            </tr>
            </tbody>
        </table>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
