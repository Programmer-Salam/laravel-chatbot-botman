<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Chatbot Ai</title>
       
        <style>
             body {
                background-color: #99ff99;
          
            } 
        </style>
    </head>
    <body>
    </body>

    <script>
	    var botmanWidget = {
	        introMessage: "✋ Hi! Welcome to Squaremart"
	    };
    </script>
    <script src='https://cdn.jsdelivr.net/npm/botman-web-widget@0/build/js/widget.js'></script>
      
</html>